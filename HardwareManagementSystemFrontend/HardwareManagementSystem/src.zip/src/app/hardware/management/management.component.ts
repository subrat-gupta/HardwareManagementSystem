import { Component } from '@angular/core';

@Component({
  selector: 'management',
  templateUrl: './management.component.html',
  styleUrl: './management.component.scss'
})
export class ManagementComponent {

}
