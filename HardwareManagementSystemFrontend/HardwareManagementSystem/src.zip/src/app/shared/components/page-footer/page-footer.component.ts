import { Component } from '@angular/core';

@Component({
  selector: 'page-footer',
  templateUrl: './page-footer.component.html',
  styleUrl: './page-footer.component.scss'
})
export class PageFooterComponent {

}
