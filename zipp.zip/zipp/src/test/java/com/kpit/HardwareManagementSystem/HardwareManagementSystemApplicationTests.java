package com.kpit.HardwareManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HardwareManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
